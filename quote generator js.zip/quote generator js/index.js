const quotes = [
    "“Be yourself; everyone else is already taken.”― Oscar Wilde",
    "The only way to do great work is to love what you do. - Steve Jobs",
    "“Don't be pushed around by the fears in your mind. Be led by the dreams in your heart.”― Roy T.Bennett, The Light in the Heart",
    "Your time is limited, don't waste it living someone else's life. - Steve Jobs",
    "“Believe in yourself. You are braver than you think, more talented than you know, and capable of more than you imagine.”― Roy T.Bennett, The Light in the Heart",
    "“Yesterday is history, tomorrow is a mystery, today is a gift of God, which is why we call it the present.”― Bill Keane",
    "Success is not final, failure is not fatal: It is the courage to continue that counts. - Winston Churchill",
    "“Life's under no obligation to give us what we expect.”― Margaret Mitchell",
    "“But I know, somehow, that only when it is dark enough can you see the stars.”― Martin Luther King, Jr.",
    "Don't stop when you are tired ,stop when you are DONE",
    "“Stay away from those people who try to disparage your ambitions. Small minds will always do that, but great minds will give you a feeling that you can become great too.” —Mark Twain",
    "“Experience is a hard teacher because she gives the test first, the lesson afterward.” ―Vernon Sanders Law",
    "“If you are working on something that you really care about, you don’t have to be pushed. The vision pulls you.” —Steve Jobs",
    "“Don’t bunt. Aim out of the ballpark. Aim for the company of immortals.” ―David Ogilvy",
    "“Inspiration does exist, but it must find you working.” —Pablo Picasso",
    "“Don’t settle for average. Bring your best to the moment. Then, whether it fails or succeeds, at least you know you gave all you had.” —Angela Bassett"
];

let shuffledQuotes = shuffleArray([...quotes]);
let currentIndex = 0;

const quoteElement = document.getElementById("quote");
const generateBtn = document.getElementById("generate-btn");

generateBtn.addEventListener("click", generateQuote);

/*function generateQuote() {
    const randomIndex = Math.floor(Math.random() * quotes.length);
    quoteElement.textContent = quotes[randomIndex];
} */

function generateQuote() {
    if (currentIndex >= shuffledQuotes.length) {
        shuffledQuotes = shuffleArray([...quotes]);
        currentIndex = 0;
    }
    quoteElement.textContent = shuffledQuotes[currentIndex];
    currentIndex++;
}

// *** Added: Function to shuffle an array ***
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}